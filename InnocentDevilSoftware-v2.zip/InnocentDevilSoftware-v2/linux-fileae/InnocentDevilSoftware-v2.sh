#!/bin/bash

while true; do
    zenity --error --text="Error: Keyboard not found. Press OK to continue."
done

Hello there! Thank you for installing Innocent Devil Software v2!

NOTICE:-

THIS APPLICATION DOES NOT MAKE ANY CHANGES OR INSTALL ANYTHING IN YOUR COMPUTER. IT IS JUST A FILE AND IT DOES NOT ASK FOR ANY PERMISSION NOR COLLECTS ANY OF YOUR INFO. MADE FOR FUN PURPOSES ONLY.

Supported OSs (for v2)

All Windows Versions

Linux

Open winfile folder for the file in Windows.

Open linux-fileae for the file in Linux

Steps for running the file in Windows:-

Extract the .zip file

Go to the winfile folder

Double click on InnocentDevilSoftware-v2.bat

Voila!

Steps for running the file in Linux:-

Open Terminal

Navigate to Downloads (type 'cd Downloads' in terminal)

Unzip it by typing "unzip InnocentDevilSoftware-v2.zip

Type "cd InnocentDevilSoftware-v2"

Type "cd linux-fileae"

Type "chmod +x InnocentDevilSoftware-v2.sh"

after that, type "./InnocentDevilSoftware-v2.sh"

(if the last step doesnt work try running it with root by adding sudo before ./)

If you like this Software, be sure to give feedback on GitHub